package com.ssafy.algo;

import java.util.*;
// 상:1, 하:2, 좌:3, 우:4 
// 1. 3칸, 2칸, 1칸: 매순간마다 다른 소금쟁이와 겹치는지 확인
// 2. 시작할 때 다른 소금쟁이가 있나 확인
// 3. 6칸 뒤에 경계를 넘었나 확인(매번 확인하면 좀 더 효율적이긴 함)
// 다 배치가 되어야 하는건가? 아니면 그냥 들어오늘 순서대로 뛰는건가?
public class Solution22 {
	static int N, S;
	static int x, y, d;
	static int ans; //살아남은 소금쟁이의 수
	static int dx[] = {-1, 1, 0, 0}; //상하좌우
	static int dy[] = {0, 0, -1, 1};
	
	static void jump(int num) { // 소금쟁이가 뜀
		for(int i = 0; i < num; i++) {
			x += dx[d - 1]; //index를 맞춰주기 위해 d-1
			y += dy[d - 1];		
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int TC = sc.nextInt();
		
		for(int t = 1; t <= TC; t++) {
			ans = 0;
			N = sc.nextInt();
			S = sc.nextInt();
			
			int[][] map = new int[N][N];
			
			for(int s = 0; s < S; s++) {
				x = sc.nextInt();
				y = sc.nextInt();
				d = sc.nextInt(); // 방향
				
				if(map[x][y] == 1)  // 시작위치에 소금쟁이가 있으면 die
					continue;
				
				//3칸 뜀
				jump(3);
				if(x < 0 || x >= N || y < 0 || y >= N) //out of range	
					continue;
				if(map[x][y] == 1) // 뛴 자리에 다른 소금쟁이가 있으면 die
					continue;
				
				//2칸 뜀
				jump(2);
				if(x < 0 || x >= N || y < 0 || y >= N) //out of range	
					continue;
				if(map[x][y] == 1) // 뛴 자리에 다른 소금쟁이가 있으면 die
					continue;
				
				//1칸 뜀
				jump(1);
				if(x < 0 || x >= N || y < 0 || y >= N) //out of range	
					continue;
				if(map[x][y] == 1) // 뛴 자리에 다른 소금쟁이가 있으면 die
					continue;
				
				//소금쟁이가 무사히 자리를 잡음
				map[x][y] = 1; 
				ans++;
			}
			if(t == 1) System.out.println();
			System.out.println("#" + t + " " + ans);
		}
	}
}
